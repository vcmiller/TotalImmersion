﻿using UnityEngine;
using System.Collections;

public class PlayerControl : MonoBehaviour {
    private Rigidbody rigidbody;
    private Transform head;
    public float moveSpeed = 5.0f;
    public float mouseSensitivity = 2.0f;
    public float jumpSpeed = 2.0f;
    public int ammo = 5;
    public float health = 100;

    private Animator weapon;

    public bool grounded { get; private set; }

	// Use this for initialization
	void Start () {
        rigidbody = GetComponent<Rigidbody>();
        head = transform.GetChild(0);
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        weapon = GetComponentInChildren<Animator>();
	}

    public void Damage(float damage) {
        health -= damage;
        if (health <= 0) {
            health = 0;
            enabled = false;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
    }

    // Update is called once per frame
    void Update () {
        grounded = IsGrounded();
        Vector3 movement = transform.forward * Input.GetAxis("Vertical") + transform.right * Input.GetAxis("Horizontal");
        rigidbody.MovePosition(transform.position + movement * Time.deltaTime * moveSpeed);

        transform.Rotate(0, Input.GetAxis("Mouse X") * mouseSensitivity, 0);
        head.Rotate(-Input.GetAxis("Mouse Y") * mouseSensitivity, 0, 0, Space.Self);

        float p = head.localEulerAngles.x;
        if (p > 80 && p < 180) {
            p = 80;
        } else if (p >= 180 && p < 280) {
            p = 280;
        }
        head.localEulerAngles = new Vector3(p, 0, 0);
        if (grounded && Input.GetButtonDown("Jump")) {
            rigidbody.AddForce(Vector3.up * jumpSpeed, ForceMode.VelocityChange);
        }


        if (Input.GetButtonDown("Fire1") && ammo > 0) {
            weapon.SetTrigger("Shoot");
            ammo--;

            RaycastHit hit;
            if (Physics.Raycast(head.position, head.forward, out hit)) {
                Enemy enemy = hit.collider.GetComponent<Enemy>();
                if (enemy != null) {
                    enemy.Damage(50);
                }
            }
        }
    }

    private bool IsGrounded() {
        return Physics.SphereCast(new Ray(transform.position, Vector3.down), 0.5f, 1.1f);
    }
}
